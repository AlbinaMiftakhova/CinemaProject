<?php
require_once      __DIR__."/phpmailer/PHPMailerAutoload.php"; 
class PHPMailSend {
  function __construct() {

  }
    /**
     * Sending Push Notification
     */
    public function send_email($email,$message) {
      $mail = new PHPMailer; 
//comment following line when upload online not on local host
      $mail->isSMTP();
      $mail->Host = 'smtp.yandex.ru';
      $mail->SMTPAuth = true;
      $mail->Username = 'albinkamiftakhova@yandex.ru';
      $mail->Password = '6Pttfq6Cr@@jP.K';
      $mail->Port=465;
      $mail->SMTPSecure = 'ssl'; 
      $mail->From = 'albinkamiftakhova@yandex.ru';
      $mail->FromName = 'CinemaProject';
      $mail->addAddress($email); 
      $mail->WordWrap = 50;
      $mail->isHTML(true); 
      $mail->Subject = 'Password recovery';
      $mail->Body    = 'Your new password: '.$message . ", you can change it in your profile";
      if(!$mail->send()) 
      {
        return 0 ;
   //echo 'Message could not be sent.';
   // echo 'Mailer Error: ' . $mail->ErrorInfo;
        exit;
      }
   //echo 'Message has been sent';        
      return 1 ;
    }
  }
  ?>