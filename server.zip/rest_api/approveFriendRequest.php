<?php
//подтверждение дружбы
$response = array();

include __DIR__ . "/GeneralFunctions.php";
include __DIR__ . "/utilities/firebaseNotification.php";
//если все необходимые данные есть
if (isset($_POST['friends_id']) && isset($_POST['request_user_id']) && isset($_POST['user_id']) && isset($_POST['token'])) {
    $user_id = $_POST['user_id']; //id пользователя
    $token = $_POST['token']; //токен
    $friends_id = $_POST['friends_id']; //запись о дружбе
    $request_user_id = $_POST['request_user_id']; //пользователь, принимающий дружбу

    $firebaseNotificationObject = new FirebaseNotificationClass();
    $generalFunctionsObject = new GeneralFunctionsClass(); //экземпляр класса GeneralFunctionsClass
    $dbOperationsObject = new DBOperations(); //экземпляр класса DBOperations
    $request_user = $generalFunctionsObject->getUserById($request_user_id); //получаем пользователя принимающего дружбу
    $approvedUser = $generalFunctionsObject->getUserById($user_id); //получаем пользователя отправляющего запрос на дружбу
    $friendInfo = $generalFunctionsObject->getFriendRelation($request_user_id, $user_id); //получаем запись о дружбе

    $result_token = $dbOperationsObject->isTokenExist($user_id, $token);
    //если токен существует
    if (mysqli_num_rows($result_token) > 0) {
        //если запись не нашлась, значит другой пользователь отозвал свой запрос о дружбе
        if ($friendInfo["friends_id"] == -1) {
            $response['success'] = 0;
            $response["message"] = "this contact cancelled this friend request ";
            echo json_encode($response);
        }
        //если запись нашлась
        else {
            //если дружба подтверждена
            if ($friendInfo["type"] == 1) {
                $response['success'] = 0;
                $response["message"] = "this contact is already in your friends list";
                echo json_encode($response);
            }
            //если еще нет
            else
                if ($friendInfo["type"] == 0) {
                    $request_user_token = $request_user["token"];
                    //выполняем запрос для подтверждения дружбы
                    $result = $dbOperationsObject->approveFriendRequest($friends_id);
                    //если запрос успешен
                    if (mysqli_affected_rows($result) > 0) {
                        $obj = new stdClass();
                        $obj->firebase_json_message = array(
                            "type" => 'approveFriendRequest',
                            "friends_id" => $friends_id,
                            "approved_user" => $approvedUser,
                        );
                        $registration_id = $generalFunctionsObject->getUserRegestrationId($request_user_id);
                        $messageFirbase = json_encode($obj);
                        $firebaseNotificationObject->send_notification($registration_id, $messageFirbase);
                        $response["success"] = 1;
                        $response['friends_id'] = $friends_id;
                        $response['request_user'] = $request_user;
                        echo json_encode($response);
                    }
                    //Если неуспешен
                    else {
                        $response["success"] = 0;
                        $response["message"] = "Oops! An error occurred.";
                        echo json_encode($response);
                    }
                }
        }
    }
    //если токен не существует
    else {
        $response["success"] = 0;
        $response["message"] = "Invalid token";
        echo json_encode($response);
    }
}
//если не все необходимые данные есть
else {
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
    echo json_encode($response);
}
?>

