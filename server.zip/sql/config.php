<?php

 // if you test local 
define("DB_HOST", "localhost");
define("DB_USER", "id16053251_admin");
define("DB_PASSWORD", "r#t2G@D+F{BadZ&!");
define("DB_NAME", "id16053251_cinema_project");