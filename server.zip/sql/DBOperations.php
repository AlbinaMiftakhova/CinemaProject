<?php
include  __DIR__."/DB.php";

class DBOperations {
  public function __constructor() {

  }

//получение пользователя по почте
  public function  getUserByEmail($email){
    $com = new DbConnect();
    $sql = "select * from User where email='$email'";
    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }
//добавление друга
  public function addFriend($request_user_id,$approved_user_id) {
    $com = new DbConnect();
    $sql = "insert into Friends(request_user_id,approved_user_id) VALUES
    ('$request_user_id','$approved_user_id' )";

    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }
//request_user_id - пользователь, принявший запрос
//approved_user_id - пользователь направивший запрос на дружбу 
//получить контакты пользователя - кому он либо сам отправлял запрос на дружбу, либо принял ее
  public function getContactsByUser($user_id){
    $com = new DbConnect();
    $sql = "SELECT user_id, name, surname, birthday, city, email, image, last_seen, friends_id, token, approved_user_id, request_user_id, about, user_date, last_seen, type from Friends, User WHERE ( ( '$user_id' != User.user_id and '$user_id' = Friends.request_user_id  and User.user_id = Friends.approved_user_id  ) or ('$user_id' != User.user_id and '$user_id'= Friends.approved_user_id and User.user_id = Friends.request_user_id and type = '1' ) ) ";

    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }

//получаем запросы на дружбу, которые отправил пользователь
  public function getFriendRequestsByUser($user_id){
    $com = new DbConnect();
    $sql = "SELECT * from Friends, User 
    WHERE( ('$user_id' != User.user_id and '$user_id'= Friends.approved_user_id and User.user_id = Friends.request_user_id and type = '0' ) ) ";

    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }

//создание пользователя 
//TODO: добавить время и картинку
  public function addUser($name, $surname, $birthday, $city, $email, $image, $password, $token, $date) {
    $com = new DbConnect();
    $name =  mysqli_real_escape_string($com->getDb(),$name);
    $email =  mysqli_real_escape_string($com->getDb(),$email);
    $birthday =  mysqli_real_escape_string($com->getDb(),$birthday);
    $city =  mysqli_real_escape_string($com->getDb(),$city);
    $image =  mysqli_real_escape_string($com->getDb(),$image);
    $surname =  mysqli_real_escape_string($com->getDb(),$surname);
    $password =  mysqli_real_escape_string($com->getDb(),$password);
    $token =  mysqli_real_escape_string($com->getDb(),$token);
    $sql = "insert into User(name, surname, birthday, city, email, image, password, token, user_date, last_seen) VALUES('$name', '$surname', '$birthday', '$city', '$email', '$image', '$password', '$token', '$date', '$date')";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }

//получить пользователя по id
  public function getUser($user_id) {
    $com = new DbConnect();
    $sql = "select * from User where user_id =  '$user_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }
//получить конкретную пару друзей
  public function getFriendRelation($friend_user_id , $user_id)
  {
    $com = new DbConnect();
    $sql = "select * from Friends WHERE ( ( request_user_id =  '$friend_user_id' and approved_user_id = '$user_id'  ) or ( request_user_id =  '$user_id' and approved_user_id = '$friend_user_id'  )) ";
    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }

//редактирование пользователя
//TODO : сделать добавление интересов
  public function editUser($user_id, $name, $surname, $birthday, $city, $email, $password, $image) {
    $com = new DbConnect();
    $name =  mysqli_real_escape_string($com->getDb(),$name);
    $email =  mysqli_real_escape_string($com->getDb(),$email);
    $password =  mysqli_real_escape_string($com->getDb(),$password);
    $surname =  mysqli_real_escape_string($com->getDb(),$surname);
    $birthday =  mysqli_real_escape_string($com->getDb(),$birthday);
    $city =  mysqli_real_escape_string($com->getDb(),$city);
    $image =  mysqli_real_escape_string($com->getDb(),$image);

    $sql = "update User set name='$name',email='$email',password='$password',surname='$surname', birthday='$birthday', city='$city', image='$image' where user_id =  '$user_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }

//обновление времени последнего входа пользователя
public function updateUserLastSeen($user_id, $last_seen) {
	$com = new DbConnect();
	$token =  mysqli_real_escape_string($com->getDb(),$token);
	$sql = "update User set last_seen='$last_seen' where user_id= '$user_id' ";
	$result = mysqli_query($com->getDb(), $sql);
	return $com->getDb();
}

//обновление токена
  public function updateUserToken($user_id, $token) {
    $com = new DbConnect();
    $token =  mysqli_real_escape_string($com->getDb(),$token);
    $sql = "update User set token='$token' where user_id= '$user_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }
  
  //обновление токена по почте
  public function updateUserTokenByEmail($email, $token) {
    $com = new DbConnect();
    $token =  mysqli_real_escape_string($com->getDb(),$token);
    $sql = "update User set token='$token' where email= '$email' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }

//обновление пароля
  public function updateUserPassword($user_id, $password) {
    $com = new DbConnect();
    $password =  mysqli_real_escape_string($com->getDb(),$password);
    $sql = "update User set password='$password' where user_id=  '$user_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }

//подтверждение дружбы
  public function approveFriendRequest($friends_id) {
    $com = new DbConnect();
    $sql = "update Friends set type='1' where friends_id=  '$friends_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }

//получение типа сообщения
  public function getMessageType($message_type_id)
  {
    $com = new DbConnect();
    $sql = "select * from Message_type where message_type_id=  '$message_type_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }

//Получение дружбы по id
  public function getUsersByFriendsId($friends_id) {
    $com = new DbConnect();
    $sql = "select * from Friends where friends_id =  '$friends_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $result;
  }

//удаление из друзей
  public function deleteFriend($friends_id) {
    $com = new DbConnect();
    $sql = "delete from Friends where friends_id=  '$friends_id' ";
    $result = mysqli_query($com->getDb(), $sql);
    return $com->getDb();
  }
  
  //удаление сообщения
  public function deleteMessageByUser($user_id,$message_id) {
   $number  = 0;
   $com1 = new DbConnect();
   $sql1 = "update Message set deleted_by_sender_id='1' where message_id =  '$message_id'  and sender_id = '$user_id'  " ;
   $sql2 = "update Message set deleted_by_receiver_id='1' where message_id =  '$message_id'  and receiver_id = '$user_id'  " ;
   mysqli_query($com1->getDb(), $sql1);
   if (mysqli_affected_rows($com1->getDb())>=0)
   {
     $number++;
     mysqli_query($com1->getDb(), $sql2);
     if (mysqli_affected_rows($com1->getDb())>=0)
     {
       $number++;
     }
   }
   return $number;
 }

//существует ли почта
 public function isEmailExist($email) {
  $com = new DbConnect();
  $email =  mysqli_real_escape_string($com->getDb(),$email);
  $sql = "select * from User where email = '$email' Limit 1";
  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}

//существует ли токен
public function isTokenExist($user_id, $token) {
  $com = new DbConnect();
  $token =  mysqli_real_escape_string($com->getDb(),$token);
  $sql = "select * from User where token = '$token' and user_id = '$user_id' Limit 1";
  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}

//существует ли учетная запись
public function isLoginExist($email, $password) {
  $com = new DbConnect();
  $email =  mysqli_real_escape_string($com->getDb(),$email);
  $password =  mysqli_real_escape_string($com->getDb(),$password);
  $sql = "select * from User where email = '$email' and password = '$password' Limit 1";
  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}

//послать сообщение
public function sendMessage($sender_id, $receiver_id,$message, $message_type_id, $date) {
  $com = new DbConnect();
  $message =  mysqli_real_escape_string($com->getDb(),$message);
  $sql = "insert into Message (sender_id,receiver_id,message,message_type_id,message_date) VALUES ('$sender_id','$receiver_id','$message','$message_type_id','$date')";

  $result = mysqli_query($com->getDb(), $sql);
  return $com->getDb();
}

//получить сообщения, которые пользователь сам отправил или принял и отсортировать по дате
public function getMessagesByUser($user_id){
  $com = new DbConnect();
  $sql = "select * from Message, User where ( Message.sender_id = '$user_id' and Message.deleted_by_sender_id = '0' and User.user_id = Message.receiver_id ) or ( Message.receiver_id = '$user_id' and Message.deleted_by_receiver_id = '0'   and User.user_id = Message.sender_id) order by Message.message_date desc";
  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}

//получить последние сообщения пользователя
//TODO: ИЗМЕНЕНО receiver_id НА sender_id!!!!!
public function getLastMessagesByUser($user_id)    {
  $com = new DbConnect();
  $sql = "SELECT messages1.* FROM Message AS messages1 LEFT JOIN Message AS messages2
  ON ((messages1.sender_id = messages2.sender_id AND messages1.receiver_id = messages2.receiver_id) 
  OR (messages1.sender_id = messages2.receiver_id AND messages1.receiver_id = messages2.receiver_id))
  AND messages1.message_id < messages2.message_id
  WHERE (messages1.sender_id = '$user_id' OR messages1.receiver_id = '$user_id') 
  AND messages2.message_id IS NULL 
  order by messages1.message_date desc ";
  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}

//получить сообщения
public function getMessagesByUserWithContact($user_id,$contact_id) {
  $com = new DbConnect();
  $sql = "select * from Message where (Message.sender_id = '$user_id' and Message.receiver_id = '$contact_id' and Message.deleted_by_sender_id = '0') or (Message.sender_id = '$contact_id' and Message.receiver_id = '$user_id' and Message.deleted_by_receiver_id = '0') order by Message.message_date asc";

  $result = mysqli_query($com->getDb(), $sql);
  return $result;
}
}